# phpMyAdmin MySQL-Dump
# version 2.2.6
# http://phpwizard.net/phpMyAdmin/
# http://www.phpmyadmin.net/ (download page)
#
# Serveur: localhost
# G�n�r� le : Samedi 05 Octobre 2002 � 00:23
# Version du serveur: 3.23.49
# Version de PHP: 4.2.0
# Base de donn�es: `localtest2`
# --------------------------------------------------------

#
# Structure de la table `table_users`
#

CREATE TABLE table_users (
  id smallint(5) NOT NULL auto_increment,
  pseudo varchar(30) NOT NULL default '',
  email varchar(250) NOT NULL default '',
  PRIMARY KEY  (id)
) TYPE=MyISAM;

#
# Contenu de la table `table_users`
#

INSERT INTO table_users VALUES (1, 'bobe', 'bobe@domain.com');
INSERT INTO table_users VALUES (2, 'AllCoKe', 'AllCoKe@domain2.net');
INSERT INTO table_users VALUES (3, 'toto', 'toto@domain3.fr');

