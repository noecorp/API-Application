<?php
  include('template.php');
  
  $connect = mysql_connect("localhost", "root", "");
  mysql_select_db("database", $connect);

  $result = mysql_query("SELECT pseudo, email FROM table_users WHERE id = '1'");
  $row = mysql_fetch_array($result);

  /*
   * Nous admettrons ici que le pseudo obtenu est bobe et l'email est bobe@domain.com
   */

  // on cr�� une nouvelle instance de la classe Template

  $template = new Template("./"); // on indique en argument le chemin vers les mod�les

  // mod�le � utiliser auquel on adjoint un nom arbitraire

  $template->set_filenames( array('body' => 'template1.tpl'));

  // Assignation des variables

  $template->assign_vars( array(
      'PSEUDO' => stripslashes($row['pseudo']),
      'EMAIL'  => $row['email']
  ));

  // Affichage des donn�es

  $template->pparse('body');
?>

